public class RunGame {
    public static void main(String[] args) {
                Menyer m = new Menyer();
                m.MainMenu();                       // kallar meny metoden

        }

}